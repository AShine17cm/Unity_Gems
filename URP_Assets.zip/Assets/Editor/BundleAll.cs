﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
public class BundleAll : MonoBehaviour
{
    static string path = "Assets/Model/mesh_Prefab.prefab";
    static string path2 = "Assets/Scenes/ShaderAB.unity";
    static string abName = "mesh_Prefab";
    static string abName2 = "ShaderX";
    static string dstDir = "Assets/StreamingAssets/scene";

    [MenuItem("Tools/打包 所有的资源")]
    public static void Init()
    {
        //AssetBundleBuild[] build = new AssetBundleBuild[1];
        //build[0].assetNames = new string[] { path };
        //build[0].assetBundleName = abName + ".ab";


        //AssetBundleManifest fest = BuildPipeline.BuildAssetBundles(
        //    dstDir, build,
        //    BuildAssetBundleOptions.ForceRebuildAssetBundle |
        //    BuildAssetBundleOptions.DeterministicAssetBundle |
        //    BuildAssetBundleOptions.ChunkBasedCompression,
        //    EditorUserBuildSettings.activeBuildTarget);


        AssetBundleBuild[] build2 = new AssetBundleBuild[1];
        build2[0].assetNames = new string[] { path2 };
        build2[0].assetBundleName = abName2 + ".ab";


        AssetBundleManifest fest2 = BuildPipeline.BuildAssetBundles(
            dstDir, build2,
            BuildAssetBundleOptions.ForceRebuildAssetBundle |
            BuildAssetBundleOptions.DeterministicAssetBundle |
            BuildAssetBundleOptions.ChunkBasedCompression,
            EditorUserBuildSettings.activeBuildTarget);
    }
}
