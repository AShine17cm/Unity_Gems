﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
public class BundleWindow : EditorWindow
{
    static EditorWindow window;
    static string path= "Assets/Variants/TestVariants.shadervariants";
    static string abName = "shader_var";
    static string dstDir = "Assets/StreamingAssets/shader";
    [MenuItem("Tools/打包 资源")]
    public static void Init()
    {
        window = GetWindow(typeof(BundleWindow), false, "打包 资源", true);
        window.minSize = new Vector2(500, 600);
        window.maxSize = new Vector2(600, 900);
        window.Show();

    }
    private void OnGUI()
    {
        path = GUILayout.TextField(path, GUILayout.Width(300));

        GUILayout.Label("Bundle Name");
        abName = GUILayout.TextField(abName, GUILayout.Width(300));

        GUILayout.Label("Build to folder");
        dstDir = GUILayout.TextField(dstDir);

        GUILayout.Space(10);
        if(GUILayout.Button("打包资源"))
        {
            Build();
            AssetDatabase.Refresh();
        }

    }
    static void Build()
    {
        BuildPipeline.BuildAssetBundles(dstDir,
            BuildAssetBundleOptions.ForceRebuildAssetBundle |
            BuildAssetBundleOptions.DeterministicAssetBundle |
            BuildAssetBundleOptions.ChunkBasedCompression,
            EditorUserBuildSettings.activeBuildTarget);

        //AssetBundleBuild[] build = new AssetBundleBuild[1];
        //build[0].assetNames = new string[] { path };
        //build[0].assetBundleName = abName + ".ab";


        //AssetBundleManifest fest = BuildPipeline.BuildAssetBundles(
        //    dstDir, build,
        //    BuildAssetBundleOptions.ForceRebuildAssetBundle | 
        //    BuildAssetBundleOptions.DeterministicAssetBundle | 
        //    BuildAssetBundleOptions.ChunkBasedCompression, 
        //    EditorUserBuildSettings.activeBuildTarget);

    }
}
