﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Optimize Mesh Data
//Mesh必须和材质相关联，比如 MeshFilter+MeshRender
//Mesh和材质 必须在打包时 被引用到，打包AB的时候，这个选项也起作用
//1. FBX+材质 在 Build的场景里
//2. Prefab+Mesh+材质 在Build的场景里

//X.1 单独的Mesh放在场景中，比如被脚本引用， (即使在资源文件夹中,存在Prefab+Mesh+材质)，也不会被优化
public class TestMeshOptimize : MonoBehaviour
{
    // Start is called before the first frame update
    public int fbxInScene_Normal;
    public int fbxInScene_Tangent;
    public int meshInScene_Normal;
    public int meshInScene_Tangent;

    public int fbxAB_Normal;
    public int fbxAB_Tangent;
    public int meshAB_Normal;
    public int meshAB_Tangent;
    public int meshAB_Vertex;

    public MeshFilter fbx_InScene;
    public Mesh mesh_InScene;
    public string fbx_ab;
    public string mesh_abFile = "/model/mesh_Prefab.ab";
    void Start()
    {
        Mesh mesh = fbx_InScene.sharedMesh;

        fbxInScene_Normal =mesh.normals.Length;
        fbxInScene_Tangent =mesh.tangents.Length;

        Mesh mesh_mesh = mesh_InScene;
        meshInScene_Normal = mesh_mesh.normals.Length;
        meshInScene_Tangent = mesh_mesh.tangents.Length;

        AssetBundle ab= AssetBundle.LoadFromFile(Application.streamingAssetsPath+ mesh_abFile);
        GameObject go= ab.LoadAsset<GameObject>("mesh_Prefab");
        MeshFilter filter= go.GetComponent<MeshFilter>();
        Mesh mesh_ab = filter.sharedMesh;
        meshAB_Normal = mesh_ab.normals.Length;
        meshAB_Tangent = mesh_ab.tangents.Length;
        meshAB_Vertex = mesh_ab.vertexCount;
    }

    // Update is called once per frame
    void Update()
    {
        
    }



    private void OnGUI()
    {
        GUIStyle style = new GUIStyle()
        {
            fontSize = 32,
        };
        GUI.BeginGroup(new Rect(300, 300, 500, 500));

        GUILayout.Label($"FBX 法线数量: {fbxInScene_Normal}",style);
        GUILayout.Label($"FBX 切线数量: {fbxInScene_Tangent}",style);
        GUILayout.Space(10);

        GUILayout.Label($"Mesh Copy 法线数量: {meshInScene_Normal}", style);
        GUILayout.Label($"Mesh Copy 切线数量: {meshInScene_Tangent}", style);
        GUILayout.Space(10);

        GUILayout.Label($"Mesh AB 法线数量: {meshAB_Normal}", style);
        GUILayout.Label($"Mesh AB 切线数量: {meshAB_Tangent}", style);
        GUILayout.Label($"Mesh AB 顶点数量: {meshAB_Vertex}", style);
        GUILayout.Space(10);
        GUI.EndGroup();
    }
}
