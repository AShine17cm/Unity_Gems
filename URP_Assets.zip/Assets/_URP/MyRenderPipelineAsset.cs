﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

[CreateAssetMenu(menuName = "Rendering/MyRenderPipelineAsset")]
public class MyRenderPipelineAsset : RenderPipelineAsset
{
    public Color myColor;
    public string myString;
    public string lightMode = "LightModeTag_1";
    protected override RenderPipeline CreatePipeline()
    {
        return new MyRenderPipeline(this);
    }

}
